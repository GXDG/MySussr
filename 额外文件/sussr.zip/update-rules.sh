#!/system/bin/sh
#
################
#KP规则更新脚本#
#  by supppig  #
################
#
echo "
==KoolProxy规则更新脚本==
=====  by supppig  =====
"
cxinfo="https://koolproxy.com/downloads/arm koolproxy . KoolProxy程序 cx cxmdf"
jtinfo="https://kprule.com/koolproxy.txt koolproxy.txt rules 静态规则 jtgx jtmdf"
spinfo="https://kprule.com/kp.dat kp.dat rules 视频规则 spgx spmdf"
safeexit()
{
${brm} -rf $predown
${brm} -f $kpdir/autoupdatepid
exit $1
}
getmdf()
{
url=$1'.md5'
var=$6
res=''
res=$(${bcurl} -L -k -s $url)
if [ "$res" != "" ];then
eval $var'='$res
else
echo ""
echo "获取$4的md5失败，退出更新！"
safeexit 1
fi
}
downloadfiles()
{
checkvar=$5
eval x=$\{${checkvar}\}
[ "$x" = "" ] && return
output=${predown}/$2
url=$1
nn=$4
${bcurl} -L -k -s -o ${output} $url 2>&1
if [ "$?" != "0" ] || [ ! -s ${output} ] ; then
echo "$nn下载失败！退出！"
safeexit 1
fi
if [ -s $output ] ; then
${bchmod} 777 ${output}
fi
}
checkdownload()
{
checkvar=$5
eval x=$\{${checkvar}\}
[ "$x" = "" ] && return
eval 'mdf='$\{${6}\}
filename=$2
nn=$4
new_md5=`${bmd5sum} $predown/$filename | ${bcut} -d' ' -f1`
if [ "$mdf" != "$new_md5" ];then
echo "$nn下载校检失败！退出！"
safeexit 1
fi
}
md5check()
{
eval 'mdf='$\{${6}\}
filedir=$3
filename=$kpdir'/'$filedir'/'$2
nn=$4
checkvar=$5
if [ -f $filename ];then
old_md5=`${bmd5sum} $filename | ${bcut} -d' ' -f1`
old_md5=${old_md5:0:6}
else
old_md5="0"
fi
new_md5=${mdf:0:6}
if [ "$old_md5" != "$new_md5" ] ; then
echo " └$nn有更新！($old_md5-->$new_md5)"
eval $checkvar'=y'
else
echo " └$nn没有更新($old_md5)"
fi
}
replace()
{
checkvar=$5
nn=$4
filedir=$3
filename=$kpdir'/'$filedir'/'$2
dlfilename=$predown'/'$2
eval x=$\{${checkvar}\}
if [ "$x" = "y" ];then
echo " └正在替换$nn文件。。。"
${brm} -f $filename
${bcp} -f $dlfilename $filename
fi
}
printkpinfo()
{
str=$($kpdir/koolproxy -v)
echo "KoolProxy版本：$str"
str=$(${bgrep} '^!x.*video' -m1 $kpdir/rules/koolproxy.txt | ${bgrep} -oE '20[0-9-]{6,8}\ ([0-9]){1,2}:[0-9]{2}')
echo "视频规则更新日期：$str"
str=$(${bgrep} '^!x.*rules' -m1 $kpdir/rules/koolproxy.txt | ${bgrep} -oE '20[0-9-]{6,8}\ ([0-9]){1,2}:[0-9]{2}')
echo "静态规则更新日期：$str"
str=$(${bgrep} -v '^!' $kpdir/rules/koolproxy.txt | ${bgrep} -v '^$' | ${bwc} -l)
[ "$str" != "" ] && echo "有效规则：$str条"
}
killkp()
{
echo "关闭KoolProxy"
${bkillall} -q koolproxy
}
cbbx()
{
type $1 2>&- >&-
if [ "$?" = "0" -a "$2" != "q" ];then
eval b$1=$1
else
eval b$1=\"$bbx $1\"
fi
}
capp()
{
type $1 2>&- >&-
if [ "$?" = "0" -a "$2" != "q" ];then
eval b$1=$1
else
eval b$1=\"$cappdir/$1\"
fi
}
automount()
{
echo "supppig" >$1/test.supppig
if [ "$?" = "0" ];then
${brm} -f $1/test.supppig
else
x=$(echo $1 | ${bcut} -d'/' -f2)
${bmount} -o rw,remount /$x 2>&- || ${bmount} -o remount,rw /$x 2>&-
fi
}
startkp()
{
kpns=""
x=$(iptables -t nat -S OUTPUT | ${bgrep} ad_block)
[ "$x" != "" ] && kpns="y"
x=$(iptables -t nat -S PREROUTING | ${bgrep} 8080 | ${bgrep} 3000)
[ "$x" != "" ] && kpns="y"
if [ "$kpns" != "" ];then
echo "重启KoolProxy"
$kpdir/koolproxy -c1 -b $kpdir -d
else
echo "检测不到KoolProxy的iptables，KoolProxy没有启动。"
fi
}
DIR="${0%/*}"
if [ -d "${DIR}/tools" ];then 
workdir=${DIR}'/tools'
kpdir=${workdir}'/KoolProxy'
elif [ -d "${DIR}/KoolProxy" ];then  
workdir=${DIR}'/KoolProxy'
kpdir=${workdir}
else
echo "搞毛，文件目录都没了？"
exit 1
fi
bbx=${workdir}'/busybox'
cappdir=$workdir
predown=$workdir/pre_download
cbbx grep
cbbx ps
cbbx cut
cbbx md5sum
cbbx rm
cbbx cp
cbbx chmod
cbbx killall
cbbx date
cbbx mkdir
cbbx mount
cbbx wc
capp curl
automount $kpdir
if [ "$1" = "a" ];then
echo "autopid=$$" >$kpdir/autoupdatepid
sleep 30
else
if [ -s "$kpdir/autoupdatepid" ];then
. $kpdir/autoupdatepid
x=$(${bps} | ${bgrep} -w $autopid | ${bgrep} sh | ${bgrep} -w root)
if [ "$x" != "" ];then
echo "
KoolProxy自动更新程序正在运行呢~~~
UID=$autopid
如果你现在手动更新KoolProxy，会冲突哦~~~
启动SuSSR后，30秒后会启动自动更新程序~~耐心等等呗~~~
可能大概1分钟后，你运行check.sh，就能看到规则已经更新啦~~~
PS:如果你不喜欢自动更新，可以在setting.ini里面关闭这个选项。
"
exit 1
fi
fi
fi
cd $DIR
${brm} -rf $predown
${bmkdir} $predown
echo -n "获取程序和规则md5。。。"
getmdf $cxinfo
getmdf $jtinfo
getmdf $spinfo
echo "完成"
echo "启动md5校检更新模式。。。"
md5check $cxinfo
md5check $jtinfo
md5check $spinfo
if [ "$cx$jtgx$spgx" = "" ];then
echo "KoolProxy规则不需更新。程序退出。"
else
downloadfiles $cxinfo
checkdownload $cxinfo
downloadfiles $jtinfo
checkdownload $jtinfo
downloadfiles $spinfo
checkdownload $spinfo
killkp
replace $cxinfo
replace $jtinfo
replace $spinfo
${bchmod} -R 777 ${kpdir}
startkp
echo "KoolProxy更新完毕！"
fi
newtime=$(${bdate} +%s)
x=$(${bdate} '+%Y-%m-%d_%H:%M')
echo "#上次检查更新时间：$x
oldtime=$newtime" >$kpdir/supppig
echo "-----------------"
printkpinfo
safeexit 0
